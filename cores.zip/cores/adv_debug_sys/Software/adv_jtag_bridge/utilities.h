
#ifndef _UTILITIES_H_
#define _UTILITIES_H_

int check_buffer_size(char **buf, int *buf_size_bytes, int requested_size_bytes);

#endif
