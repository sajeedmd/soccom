#ifndef _BSDL_PARSE_H_
#define _BSDL_PARSE_H_

#include "bsdl.h"  // need definition of bsdlinfo here


bsdlinfo * parse_extract_values(char *bsdlfilename);

#endif
