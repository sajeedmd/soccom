#ifndef _ADV_JTAG_BRIDGE_H_
#define _ADV_JTAG_BRIDGE_H_

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif


#endif /* _ADV_JTAG_BRIDGE_H_ */

